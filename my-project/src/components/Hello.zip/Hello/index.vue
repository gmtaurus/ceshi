<template src='./_vue.html'></template>
<style src='./_vue.css'></style>
<script src='./_vue.js'></script>