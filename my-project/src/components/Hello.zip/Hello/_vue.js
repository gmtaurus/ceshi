import axios from 'axios';
import $ from 'jquery';

$(window).scroll(function() {
console.log("滚动条到顶部的垂直高度: "+$(document).scrollTop());
console.log("页面的文档高度 ："+$(document).height());
console.log('浏览器的高度：'+$(window).height());
    if($(document).scrollTop()+$(window).height()+50>$(document).height()) {
        // alert(1);
    }
});
export default {
    data() {
        return {
            sideList: [{
                name: "推荐"
            }, {
                name: "热点"
            }, {
                name: "视频"
            }, {
                name: "图片"
            }, {
                name: "段子"
            }, {
                name: "社会"
            }, {
                name: "娱乐"
            }, {
                name: "科技"
            }, {
                name: "体育"
            }, {
                name: "汽车"
            }, {
                name: "财经"
            }, {
                name: "搞笑"
            }, {
                name: "更多"
            }],
            topBanners: [],
            topBanner: '',
            newsLists: [],
            // documentHeight: $(document).height(),
            lazy: 0,
            // windowHeight: $(document).height(),
        };
    },
    watch: {
        lazy() {
            if(this.lazy === 1) {
                this.getNewsList();
            }else {

            }
        }
    },
    methods: {
        lazyLoad() {
            let me = this;
            $(window).scroll(function() {
            console.log("滚动条到顶部的垂直高度: "+$(document).scrollTop());
            console.log("页面的文档高度 ："+$(document).height());
            console.log('浏览器的高度：'+$(window).height());
                if($(document).scrollTop()+$(window).height()+50>$(document).height()) {
                    // alert(1);
                    me.lazy = 1;
                }else {
                    me.lazy = 0;
                }
            });
        },
        getNewsList() {
            let me = this;
            $.ajax({
                dataType: "jsonp",
                url: "https://www.toutiao.com/api/pc/feed/?min_behot_time=0&category=__all__&utm_source=toutiao&widen=1&tadrequire=true&as=A12519F7C000D95&cp=5970509DC9458E1",
                data: {},
                success: function(data) {
                    console.log(data)
                    for(let i = 0; i < data.data.length; i++) {
                        me.newsLists.push({
                            image_url: data.data[i].image_url,
                            media_avatar_url: data.data[i].media_avatar_url,
                            title: data.data[i].title,
                            tag: data.data[i].chinese_tag,
                            source: data.data[i].source,
                            comments: data.data[i].comments_count,
                        })
                    }
                    // me.newsLists = data.data;

                }
            })
        },
        // focusShow () {
        //     // if(picture.length != 0){
        //         var picture = document.querySelectorAll(".picture li");
        //         var stopTimer = null;
        //         // for(let i=0; i<picture.length; i++) {
        //         //     $(this).show();
        //         // }
        //         console.log(picture);
        //         var j = 1;
        //         stopTimer = setInterval(function () {
        //             if(j === 5) {
        //                 j = 0;
        //                 picture[0].show().sibilings().hide();
        //             } else {
        //                 picture[j].show().sibilings().hide();
        //                 j++;
        //             }
        //         },3000);
        //     // }
            
        // }
        focusShow () {
            let me = this;
            console.log(this.topBanners)
            console.log(this.topBanners.length)
            console.log(this.topBanner)
            let j = 1
            setTimeout(function(){
                if(j === 6) {
                    me.topBanners[0].class = "displayBlock";
                }else {
                    me.topBanners[j].class = "displayBlock";
                    j++
                }
                // console.log(j);
            },2000)
            
        }
    },
    created() {
        this.getNewsList();
        var me = this;
        //获取天气
        $.ajax({
            type : 'get',
            dataType : 'jsonp',
            url: 'https://www.toutiao.com/stream/widget/local_weather/data/?city=%E5%8C%97%E4%BA%AC',
            data : {},
            success : function(result) {
                // console.log(result);
            }
        })
        $.ajax({
            type : 'get',
            dataType : 'jsonp',
            url: 'http://www.toutiao.com/api/pc/focus/',
            data : {},
            async: false,
            success : function(data) {
                var focus = data.data.pc_feed_focus;
                for (let i = 0; i < focus.length; i++) {
                    if(i < 6) {
                        me.topBanners.push({
                            image_url: focus[i].image_url,
                            title: focus[i].title,
                            class: 'displayNone',
                        })
                    }
                }
                me.focusShow();
            }
           
        })
        me.lazyLoad();
    }
}